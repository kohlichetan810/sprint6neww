package com.cg.ibs.loanmgmt.repositories;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.models.DocumentBean;

public interface DocumentDao {
	List<DocumentBean> getDocumentByApplicantNum(BigInteger applicantNum);

	DocumentBean uploadDocuments(DocumentBean document);
}
