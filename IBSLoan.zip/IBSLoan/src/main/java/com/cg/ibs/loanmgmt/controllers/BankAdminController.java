
package com.cg.ibs.loanmgmt.controllers;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.services.BankAdminService;
import com.cg.ibs.loanmgmt.services.VerifyLoanService;

@Controller
@Scope("session")
public class BankAdminController {
	@Autowired
	private BankAdminService bankAdminService;
	@Autowired
	private VerifyLoanService verifyLoanService;

	BankAdmins bankAdmin = new BankAdmins();
	LoanMaster loanMaster = new LoanMaster();

	@RequestMapping(method = RequestMethod.GET, value = "/bankAdmin")
	public ModelAndView loginRole(@RequestParam("userId") String userId) {
		ModelAndView modelAndView = new ModelAndView();
		bankAdmin = bankAdminService.getBankAdmin(userId);
		modelAndView.addObject("loginVerified", "Welcome " + bankAdmin.getAdminId());
		modelAndView.setViewName("loggedinBankAdminPage");
		return modelAndView;
	}

	@RequestMapping(value = "/verifyLoan")
	public ModelAndView viewPendingLoans() {
		List<LoanMaster> pendingLoans = verifyLoanService.getPendingLoanList();
		return new ModelAndView("verifyLoan", "pendingLoans", pendingLoans);
	}

	@RequestMapping(value = "/verifyLoan1")
	public ModelAndView selectLoanVerify(@RequestParam("loanApplicationNumber") BigInteger loanApplicationNumber) {
		List<LoanMaster> pendingLoans = verifyLoanService.getPendingLoanList();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("pendingLoans", pendingLoans);
		loanMaster.setApplicationNumber(loanApplicationNumber);
		modelAndView.addObject("lApplicationNo", loanApplicationNumber);
		modelAndView.setViewName("verifyLoan");
		return modelAndView;
	}

	@RequestMapping(value = "/verifyLoan2")
	public ModelAndView viewCompleteDetails() {
		List<LoanMaster> pendingLoans = verifyLoanService.getPendingLoanList();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("pendingLoans", pendingLoans);
		loanMaster = verifyLoanService.getLoanByAppNum(loanMaster.getApplicationNumber());
		modelAndView.addObject("lMaster", loanMaster);
		modelAndView.setViewName("verifyLoan");
		return modelAndView;

	}

//	@RequestMapping(value = "/verifyLoan3")
//	public ModelAndView downloadDoc() {
//		return null;
//
//	}
}
