package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.repositories.LoanMasterDao;

@Service
public class VerifyLoanServiceImpl implements VerifyLoanService {

	@Autowired
	private LoanMasterDao loanMasterDao;

	@Override
	public List<LoanMaster> getPendingLoanList() {
		return loanMasterDao.getSentForVerificationLoans();
	}

	@Override
	public LoanMaster getLoanByAppNum(BigInteger loanApplicationNumber) {
		return loanMasterDao.getLoanByApplicantNumber(loanApplicationNumber);
	}

}
