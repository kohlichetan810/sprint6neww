package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.models.LoanMaster;

public interface VerifyLoanService {

	List<LoanMaster> getPendingLoanList();

	LoanMaster getLoanByAppNum(BigInteger loanApplicationNumber);

}
