package com.cg.ibs.loanmgmt.services;

import java.math.BigDecimal;
import java.util.List;

import com.cg.ibs.loanmgmt.models.AccountHolding;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;

public interface ApplyLoanService {
	LoanTypeBean getLoanTypeByTypeID(Integer typeId);

	LoanMaster calculateEmi(LoanMaster loanMaster);

	BigDecimal calculatePaidInterest(LoanMaster loanMaster);

	BigDecimal calculatePaidPrinciple(LoanMaster loanMaster);
	
	List<AccountHolding> getSavingAccountListByUci(CustomerBean customer);

	void sendLoanForVerification(LoanMaster globalLoanMaster);
}
