package com.cg.ibs.loanmgmt.models;

public enum ApplicantStatus {
	PENDING, APPROVED, DENIED;
}
